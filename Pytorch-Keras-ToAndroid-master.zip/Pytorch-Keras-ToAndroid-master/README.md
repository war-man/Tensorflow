# Pytorch-Keras-ToAndroid

This repo contains codes to convert models between Pytorch-Keras-Tensorflow<br>

The Converter is in the script file [Convert.py](convert.py) <br>

Also contained is a complete Android Project source code with Image Prediction.
The App code is in [Android Sample](android-sample) <br>

The Android App uses Tensorflow-Mobile.

You can find a prebuilt Sample APK in the release section.



  <b>Reach to me Via</b> <br>
    <i>Email: </i>    <a style="text-decoration: none;"  href="mailto:johnolafenwa@gmail.com"> johnolafenwa@gmail.com</a> <br>
      <i>Website: </i>    <a style="text-decoration: none;" target="_blank" href="https://john.specpal.science"> https://john.specpal.science</a> <br>
      <i>Twitter: </i>    <a style="text-decoration: none;" target="_blank" href="https://twitter.com/johnolafenwa"> @johnolafenwa</a> <br>
      <i>Medium : </i>    <a style="text-decoration: none;" target="_blank" href="https://medium.com/@johnolafenwa"> @johnolafenwa</a> <br>
      <i>Facebook : </i>    <a style="text-decoration: none;" href="https://facebook.com/olafenwajohn"> olafenwajohn</a> <br>







